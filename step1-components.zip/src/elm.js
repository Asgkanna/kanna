import { Component } from "react";

class Elm extends Component{
    render(){
        let txt1 = "List Item 1";
        let txt2 = "List Item 2";
    return <ul>
        <li>{ txt1 }</li>
        <li>{ txt2 }</li>
    </ul>
    }
}

// export{ Elm }
export default Elm;